﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FarmAndCountry.Data.Migrations
{
    public partial class finalExam : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Country",
                columns: table => new
                {
                    CountryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CountryCapital = table.Column<string>(nullable: false),
                    CountryDescription = table.Column<string>(maxLength: 255, nullable: false),
                    CountryImageUrl = table.Column<string>(nullable: true),
                    CountryName = table.Column<string>(nullable: false),
                    CountryPopulation = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Country", x => x.CountryId);
                });

            migrationBuilder.CreateTable(
                name: "Province",
                columns: table => new
                {
                    ProvinceId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProvinceCapital = table.Column<string>(nullable: false),
                    ProvinceDescription = table.Column<string>(maxLength: 255, nullable: false),
                    ProvinceImageUrl = table.Column<string>(nullable: true),
                    ProvinceName = table.Column<string>(nullable: false),
                    ProvincePopulation = table.Column<int>(nullable: false),
                    ProvinceWebsite = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Province", x => x.ProvinceId);
                });

            migrationBuilder.CreateTable(
                name: "Farm",
                columns: table => new
                {
                    FarmId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FarmDescription = table.Column<string>(maxLength: 255, nullable: true),
                    FarmImageUrl = table.Column<string>(nullable: true),
                    FarmName = table.Column<string>(nullable: false),
                    FarmRegionCode = table.Column<string>(maxLength: 32, nullable: false),
                    FarmerCity = table.Column<string>(nullable: false),
                    FarmerCountryCountryId = table.Column<int>(nullable: false),
                    FarmerEmail = table.Column<string>(nullable: false),
                    FarmerFirstName = table.Column<string>(nullable: false),
                    FarmerLastName = table.Column<string>(nullable: false),
                    FarmerPhone = table.Column<string>(nullable: false),
                    FarmerWebsite = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Farm", x => x.FarmId);
                    table.ForeignKey(
                        name: "FK_Farm_Country_FarmerCountryCountryId",
                        column: x => x.FarmerCountryCountryId,
                        principalTable: "Country",
                        principalColumn: "CountryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Farm_FarmerCountryCountryId",
                table: "Farm",
                column: "FarmerCountryCountryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Farm");

            migrationBuilder.DropTable(
                name: "Province");

            migrationBuilder.DropTable(
                name: "Country");
        }
    }
}
