﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FarmAndCountry.Models
{
    public class Province
    {
        [Key]
        [Display(Name = "ID")]
        public int ProvinceId { get; set; }
        [Required]
        [Display(Name = "Name")]
        public string ProvinceName { get; set; }
        [Required MaxLength(255)]
        [Display(Name = "Description")]
        public string ProvinceDescription { get; set; }
        [Display(Name = "Picture")]
        public string ProvinceImageUrl { get; set; }
        [Required]
        [Display(Name = "Capital")]
        public string ProvinceCapital { get; set; }
        [Display(Name = "Population")]
        public Int32 ProvincePopulation { get; set; }
        [Display(Name = "Website")]
        public string ProvinceWebsite { get; set; }

    }
}
