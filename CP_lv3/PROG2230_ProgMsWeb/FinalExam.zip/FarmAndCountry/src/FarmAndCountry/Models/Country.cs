﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FarmAndCountry.Models
{
    public class Country
    {
        [Key]
        [Display(Name = "Country ID")]
        public int CountryId { get; set; }
        [Required]
        [Display(Name = "Name")]
        public string CountryName { get; set; }
        [Required]
        [Display(Name = "Capital")]
        public string CountryCapital { get; set; }
        [Required MaxLength(255)]
        [Display(Name = "Description")]
        public string CountryDescription { get; set; }
        [Display(Name = "Picture")]
        [Required]
        public string CountryImageUrl { get; set; }
        [Display(Name = "Population")]
        [Required]
        public Int32 CountryPopulation { get; set; }

    }
}
