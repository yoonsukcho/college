﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace FarmAndCountry.Models
{
    public class Farm
    {
        [Key]
        [Display(Name ="ID")]
        public int FarmId { get; set; }
        [Required]
        [Display(Name = "Name")]
        public string FarmName { get; set; }
        [MaxLength(255)]
        [Display(Name = "Description")]
        public string FarmDescription { get; set; }
        [Required MaxLength(32)]
        [Display(Name = "Region Code")]
        public string FarmRegionCode { get; set; }
        [Display(Name = "Picture")]
        public string FarmImageUrl { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string FarmerFirstName { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        public string FarmerLastName { get; set; }
        [Required]
        [Display(Name = "City")]
        public string FarmerCity { get; set; }
        [Required]
        [Display(Name = "Phone")]
        public string FarmerPhone { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string FarmerEmail { get; set; }
        [Display(Name = "Website")]
        public string FarmerWebsite { get; set; }
        [Required]
        [Display(Name = "Country ID")]
        public int FarmerCountryCountryId { get; set; }

        public Country FarmerCountry { get; set; }
    }
}
