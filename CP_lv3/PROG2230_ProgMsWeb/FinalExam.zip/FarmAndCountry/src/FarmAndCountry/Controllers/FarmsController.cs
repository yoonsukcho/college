using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FarmAndCountry.Data;
using FarmAndCountry.Models;

namespace FarmAndCountry.Controllers
{
    public class FarmsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FarmsController(ApplicationDbContext context)
        {
            _context = context;    
        }

        // GET: Farms
        public async Task<IActionResult> Index()
        {
            var farm = new List<Farm>();
            try
            {
                farm = await _context.Farm.ToListAsync();
                ViewData["ControllerResult"] = "Success to make a list.";
            }
            catch(Exception)
            {
                ViewData["ControllerResult"] = "Error has occured.";
            }

            return View(farm);
        }

        // GET: Farms/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }

            return View(farm);
        }

        // GET: Farms/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Farms/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FarmId,FarmDescription,FarmImageUrl,FarmName,FarmRegionCode,FarmerCity,FarmerEmail,FarmerFirstName,FarmerLastName,FarmerPhone,FarmerWebsite,FarmerCountryCountryId")] Farm farm)
        {
            //if (ModelState.IsValid)
            //{
            try
            {
                _context.Add(farm);
                await _context.SaveChangesAsync();
                ViewData["ControllerResult"] = "Success to create";
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                ViewData["ControllerResult"] = "Fail to create";
                ViewData["ErrorMssage"] = e.Message;
            }
            //}
            return View(farm);
        }

        // GET: Farms/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }
            return View(farm);
        }

        // POST: Farms/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FarmId,FarmDescription,FarmImageUrl,FarmName,FarmRegionCode,FarmerCity,FarmerEmail,FarmerFirstName,FarmerLastName,FarmerPhone,FarmerWebsite")] Farm farm)
        {
            if (id != farm.FarmId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(farm);
                    await _context.SaveChangesAsync();
                    ViewData["ControllerResult"] = "Success to edit";
                }
                catch (Exception e)
                {
                    ViewData["ControllerResult"] = "Fail to edit";
                    ViewData["ErrorMssage"] = e.Message;
                    if (!FarmExists(farm.FarmId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index");
            }
            return View(farm);
        }

        // GET: Farms/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }

            return View(farm);
        }

        // POST: Farms/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {

            var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
            try
            {
                _context.Farm.Remove(farm);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                ViewData["ControllerResult"] = "Fail to delete";
                ViewData["ErrorMssage"] = e.Message;
            }
            return View(farm);

        }

        private bool FarmExists(int id)
        {
            return _context.Farm.Any(e => e.FarmId == id);
        }
    }
}
