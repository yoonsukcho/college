﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MidTermSolution.Models
{
    public class Customer
    {
        public Customer()
        {
            //Customer Constructor

        }
        [Key]
        public int CustomerId { get; set; }
        public string CustLName { get; set; }
        public string CustFName { get; set; }
        public string CustAddress { get; set; }
        public string CustCity { get; set; }
        public string CustState { get; set; }
        public string CustZip { get; set; }
        public string CustPhone { get; set; }
        public string CustEmail { get; set; }
        public int CustomerFK { get; set; }
        

    }
}
